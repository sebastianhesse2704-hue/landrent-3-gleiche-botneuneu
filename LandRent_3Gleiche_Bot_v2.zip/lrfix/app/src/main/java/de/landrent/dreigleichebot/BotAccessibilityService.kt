package de.landrent.dreigleichebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: BotAccessibilityService? = null
        const val PREFS = "bot_prefs"
        const val KEY_START_REQUESTED = "start_requested"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private val engine = BotEngine()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // Wenn der Nutzer den Bot vor dem Verbinden gestartet hat,
        // wird er hier automatisch fortgesetzt.
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_START_REQUESTED, false)) {
            startBotInternal()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopBotInternal(clearRequest = false)
    }

    override fun onDestroy() {
        stopBotInternal(clearRequest = false)
        instance = null
        super.onDestroy()
    }

    fun startBot() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_START_REQUESTED, true)
            .apply()
        startBotInternal()
    }

    fun stopBot() {
        stopBotInternal(clearRequest = true)
    }

    private fun startBotInternal() {
        if (running) return
        running = true
        step()
    }

    private fun stopBotInternal(clearRequest: Boolean) {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (clearRequest) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_START_REQUESTED, false)
                .apply()
        }
    }

    private fun step() {
        if (!running) return
        takeScreenshot(0, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hardware = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val bitmap = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (bitmap != null) {
                        val action = engine.chooseMove(bitmap)
                        bitmap.recycle()
                        if (action != null) tap(action.x, action.y)
                    }
                } catch (_: Throwable) {
                    // Bei einem einzelnen Screenshot-Fehler nicht abbrechen.
                }
                handler.postDelayed({ step() }, 700)
            }

            override fun onFailure(errorCode: Int) {
                handler.postDelayed({ step() }, 1000)
            }
        })
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(gesture, null, null)
    }

}
