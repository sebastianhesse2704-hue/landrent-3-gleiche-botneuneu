package de.landrent.dreigleichebot

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Land Rent – 3 Gleiche Bot"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(16, 36, 16, 20)
        }
        val info = TextView(this).apply {
            text = "1. Bedienungshilfe aktivieren.\n2. Land Rent öffnen.\n3. BOT STARTEN drücken.\n\nDer Bot prüft den Bildschirm nach jedem Zug neu."
            textSize = 17f
            setPadding(24, 8, 24, 12)
        }
        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(24, 8, 24, 20)
        }
        val settings = Button(this).apply {
            text = "BEDIENUNGSHILFE ÖFFNEN"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "BOT STARTEN"
            setOnClickListener {
                if (!isAccessibilityEnabled()) {
                    Toast.makeText(this@MainActivity, "Bitte zuerst die Bedienungshilfe einschalten.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    return@setOnClickListener
                }
                getSharedPreferences(BotAccessibilityService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(BotAccessibilityService.KEY_START_REQUESTED, true).apply()
                val service = BotAccessibilityService.instance
                if (service != null) {
                    service.startBot()
                    status.text = "Status: BOT LÄUFT"
                } else {
                    status.text = "Status: Bedienungshilfe ist aktiv – Dienst wird verbunden …"
                    Toast.makeText(this@MainActivity, "Der Bot-Dienst wird gestartet. Bitte kurz warten.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "BOT STOPPEN"
            setOnClickListener {
                BotAccessibilityService.instance?.stopBot()
                getSharedPreferences(BotAccessibilityService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(BotAccessibilityService.KEY_START_REQUESTED, false).apply()
                status.text = "Status: BOT GESTOPPT"
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(title)
            addView(info)
            addView(status)
            addView(settings)
            addView(start)
            addView(stop)
        })
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (isAccessibilityEnabled()) {
                if (BotAccessibilityService.instance != null) "Status: Bedienungshilfe verbunden" else "Status: Bedienungshilfe aktiviert"
            } else {
                "Status: Bedienungshilfe AUS"
            }
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val expected = ComponentName(this, BotAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
