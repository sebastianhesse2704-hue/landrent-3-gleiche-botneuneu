package de.landrent.dreigleichebot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

class BotEngine {
    data class Action(val x: Float, val y: Float)

    fun chooseMove(bitmap: Bitmap): Action? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 500) return null

        // Konservativer Scan des zentralen Spielfeldes.
        // Der obere Bereich (Tray) wird bewusst ausgelassen.
        val left = (w * 0.10f).toInt()
        val right = (w * 0.90f).toInt()
        val top = (h * 0.25f).toInt()
        val bottom = (h * 0.88f).toInt()
        val stepX = max(50, w / 9)
        val stepY = max(50, h / 13)

        var bestX = -1
        var bestY = -1
        var bestScore = 0

        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val score = colorfulness(bitmap, x, y, min(stepX, stepY) / 3)
                if (score > bestScore) {
                    bestScore = score
                    bestX = x
                    bestY = y
                }
                x += stepX
            }
            y += stepY
        }

        return if (bestScore >= 35) Action(bestX.toFloat(), bestY.toFloat()) else null
    }

    private fun colorfulness(b: Bitmap, cx: Int, cy: Int, r: Int): Int {
        var total = 0
        var count = 0
        val x0 = max(0, cx - r)
        val x1 = min(b.width - 1, cx + r)
        val y0 = max(0, cy - r)
        val y1 = min(b.height - 1, cy + r)
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val c = b.getPixel(x, y)
                val mx = max(Color.red(c), max(Color.green(c), Color.blue(c)))
                val mn = min(Color.red(c), min(Color.green(c), Color.blue(c)))
                total += (mx - mn) / 8
                count++
                x += max(2, r / 4)
            }
            y += max(2, r / 4)
        }
        return if (count == 0) 0 else total / count
    }
}
