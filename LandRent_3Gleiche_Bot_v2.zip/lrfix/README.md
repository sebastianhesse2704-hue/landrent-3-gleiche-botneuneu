# Land Rent – 3 Gleiche Bot v2

Korrigierte Android-Version: Der Startknopf merkt sich den Startwunsch, der Accessibility-Dienst übernimmt ihn beim Verbinden, und die App zeigt den Verbindungsstatus an.

Die eigentliche Bilderkennung bleibt der bisherige konservative Prototyp und muss für das konkrete Spiel-Layout noch getestet/verbessert werden.
